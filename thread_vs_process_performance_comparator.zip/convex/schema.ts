import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  performanceTests: defineTable({
    taskType: v.string(),
    taskSize: v.number(),
    executionType: v.string(), // "threads" or "processes"
    executionTime: v.number(),
    cpuUsage: v.number(),
    memoryUsage: v.number(),
    overhead: v.number(),
    result: v.number(),
    timestamp: v.number(),
    userId: v.optional(v.id("users")),
  }).index("by_user", ["userId"])
    .index("by_timestamp", ["timestamp"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
