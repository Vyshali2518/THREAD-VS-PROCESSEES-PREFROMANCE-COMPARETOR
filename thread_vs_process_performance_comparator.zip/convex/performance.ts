import { query, mutation, action } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const saveTestResult = mutation({
  args: {
    taskType: v.string(),
    taskSize: v.number(),
    executionType: v.string(),
    executionTime: v.number(),
    cpuUsage: v.number(),
    memoryUsage: v.number(),
    overhead: v.number(),
    result: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    
    return await ctx.db.insert("performanceTests", {
      ...args,
      timestamp: Date.now(),
      userId: userId || undefined,
    });
  },
});

export const getTestHistory = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    
    return await ctx.db
      .query("performanceTests")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);
  },
});

export const runPerformanceTest = action({
  args: {
    taskType: v.string(),
    taskSize: v.number(),
    executionType: v.string(),
  },
  handler: async (ctx, args) => {
    // Simulate CPU-intensive task execution
    const startTime = Date.now();
    
    let result;
    if (args.taskType === "prime") {
      result = await simulatePrimeCalculation(args.taskSize, args.executionType);
    } else if (args.taskType === "fibonacci") {
      result = await simulateFibonacci(args.taskSize, args.executionType);
    } else {
      result = await simulateMatrixMultiplication(args.taskSize, args.executionType);
    }
    
    const executionTime = Date.now() - startTime;
    
    // Simulate different performance characteristics for threads vs processes
    const baseOverhead = args.executionType === "processes" ? 50 : 10;
    const overhead = baseOverhead + Math.random() * 20;
    
    const cpuUsage = Math.min(100, 30 + (args.taskSize / 1000) * 40 + Math.random() * 20);
    const memoryUsage = args.executionType === "processes" 
      ? 20 + (args.taskSize / 100) * 5 + Math.random() * 10
      : 10 + (args.taskSize / 100) * 2 + Math.random() * 5;
    
    const testResult = {
      taskType: args.taskType,
      taskSize: args.taskSize,
      executionType: args.executionType,
      executionTime,
      cpuUsage: Math.round(cpuUsage * 100) / 100,
      memoryUsage: Math.round(memoryUsage * 100) / 100,
      overhead: Math.round(overhead * 100) / 100,
      result,
    };
    
    // Save to database
    await ctx.runMutation(api.performance.saveTestResult, testResult);
    
    return testResult;
  },
});

async function simulatePrimeCalculation(limit: number, executionType: string): Promise<number> {
  // Simulate prime calculation with different performance for threads vs processes
  const delay = executionType === "processes" ? limit * 2 : limit * 1.5;
  await new Promise(resolve => setTimeout(resolve, Math.min(delay, 5000)));
  
  // Return simulated prime count
  return Math.floor(limit / Math.log(limit));
}

async function simulateFibonacci(n: number, executionType: string): Promise<number> {
  const delay = executionType === "processes" ? n * 10 : n * 8;
  await new Promise(resolve => setTimeout(resolve, Math.min(delay, 5000)));
  
  // Return simulated fibonacci result (just the input for demo)
  return n;
}

async function simulateMatrixMultiplication(size: number, executionType: string): Promise<number> {
  const delay = executionType === "processes" ? size * 5 : size * 4;
  await new Promise(resolve => setTimeout(resolve, Math.min(delay, 5000)));
  
  // Return simulated matrix operations count
  return size * size * size;
}
