import { useEffect, useRef, useState } from "react";

interface TestResult {
  taskType: string;
  taskSize: number;
  executionType: string;
  executionTime: number;
  cpuUsage: number;
  memoryUsage: number;
  overhead: number;
  result: number;
}

interface RealTimeChartProps {
  results: TestResult[];
}

export function RealTimeChart({ results }: RealTimeChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedMetric, setSelectedMetric] = useState<"executionTime" | "cpuUsage" | "memoryUsage">("executionTime");
  const [animationFrame, setAnimationFrame] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || results.length === 0) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = 600;
    canvas.height = 300;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Chart dimensions
    const margin = { top: 20, right: 40, bottom: 40, left: 60 };
    const chartWidth = canvas.width - margin.left - margin.right;
    const chartHeight = canvas.height - margin.top - margin.bottom;

    // Get data for selected metric
    const threadData = results.filter(r => r.executionType === "threads");
    const processData = results.filter(r => r.executionType === "processes");
    
    const allValues = results.map(r => r[selectedMetric]);
    const maxValue = Math.max(...allValues);
    const minValue = Math.min(...allValues);
    const valueRange = maxValue - minValue || 1;

    // Draw background
    ctx.fillStyle = "#f8fafc";
    ctx.fillRect(margin.left, margin.top, chartWidth, chartHeight);

    // Draw grid
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const y = margin.top + (chartHeight / 5) * i;
      ctx.beginPath();
      ctx.moveTo(margin.left, y);
      ctx.lineTo(margin.left + chartWidth, y);
      ctx.stroke();
    }

    // Draw lines
    const drawLine = (data: TestResult[], color: string) => {
      if (data.length < 2) return;

      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.beginPath();

      data.forEach((point, index) => {
        const x = margin.left + (index / (data.length - 1)) * chartWidth;
        const normalizedValue = (point[selectedMetric] - minValue) / valueRange;
        const y = margin.top + chartHeight - (normalizedValue * chartHeight);

        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });

      ctx.stroke();

      // Draw points
      ctx.fillStyle = color;
      data.forEach((point, index) => {
        const x = margin.left + (index / (data.length - 1)) * chartWidth;
        const normalizedValue = (point[selectedMetric] - minValue) / valueRange;
        const y = margin.top + chartHeight - (normalizedValue * chartHeight);
        
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fill();
      });
    };

    if (threadData.length > 0) drawLine(threadData, "#3b82f6");
    if (processData.length > 0) drawLine(processData, "#10b981");

    // Draw axes labels
    ctx.fillStyle = "#374151";
    ctx.font = "12px sans-serif";
    ctx.textAlign = "center";

    // Y-axis labels
    for (let i = 0; i <= 5; i++) {
      const value = minValue + (valueRange / 5) * (5 - i);
      const y = margin.top + (chartHeight / 5) * i;
      ctx.textAlign = "right";
      ctx.fillText(Math.round(value).toString(), margin.left - 10, y + 4);
    }

    // X-axis label
    ctx.textAlign = "center";
    ctx.fillText("Test Runs", canvas.width / 2, canvas.height - 10);

    // Y-axis label
    ctx.save();
    ctx.translate(15, canvas.height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    const metricLabels = {
      executionTime: "Execution Time (ms)",
      cpuUsage: "CPU Usage (%)",
      memoryUsage: "Memory Usage (MB)"
    };
    ctx.fillText(metricLabels[selectedMetric], 0, 0);
    ctx.restore();

    // Animate
    setAnimationFrame(prev => prev + 1);
  }, [results, selectedMetric, animationFrame]);

  // Auto-refresh animation
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationFrame(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const getMetricUnit = (metric: string) => {
    switch (metric) {
      case "executionTime": return "ms";
      case "cpuUsage": return "%";
      case "memoryUsage": return "MB";
      default: return "";
    }
  };

  const getLatestValue = (executionType: string) => {
    const filtered = results.filter(r => r.executionType === executionType);
    if (filtered.length === 0) return null;
    return filtered[filtered.length - 1][selectedMetric];
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Real-time Performance</h3>
        <select
          value={selectedMetric}
          onChange={(e) => setSelectedMetric(e.target.value as any)}
          className="px-3 py-1 border border-gray-300 rounded text-sm"
        >
          <option value="executionTime">Execution Time</option>
          <option value="cpuUsage">CPU Usage</option>
          <option value="memoryUsage">Memory Usage</option>
        </select>
      </div>

      <div className="flex justify-center mb-4">
        <canvas
          ref={canvasRef}
          className="border border-gray-200 rounded"
          style={{ maxWidth: "100%", height: "auto" }}
        />
      </div>

      {/* Current Values */}
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center p-3 bg-blue-50 rounded-lg">
          <div className="text-sm text-blue-600 font-medium">Threads</div>
          <div className="text-2xl font-bold text-blue-800">
            {getLatestValue("threads")?.toFixed(1) || "—"}
            <span className="text-sm ml-1">{getMetricUnit(selectedMetric)}</span>
          </div>
        </div>
        <div className="text-center p-3 bg-green-50 rounded-lg">
          <div className="text-sm text-green-600 font-medium">Processes</div>
          <div className="text-2xl font-bold text-green-800">
            {getLatestValue("processes")?.toFixed(1) || "—"}
            <span className="text-sm ml-1">{getMetricUnit(selectedMetric)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
