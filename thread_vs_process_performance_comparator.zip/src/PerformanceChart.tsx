import { useEffect, useRef, useState } from "react";

interface TestResult {
  taskType: string;
  taskSize: number;
  executionType: string;
  executionTime: number;
  cpuUsage: number;
  memoryUsage: number;
  overhead: number;
  result: number;
}

interface PerformanceChartProps {
  results: TestResult[];
}

export function PerformanceChart({ results }: PerformanceChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [chartType, setChartType] = useState<"bar" | "line">("bar");
  const [showMetrics, setShowMetrics] = useState({
    executionTime: true,
    cpuUsage: true,
    memoryUsage: true,
    overhead: true,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || results.length === 0) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = 1000;
    canvas.height = 500;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Chart dimensions
    const margin = { top: 60, right: 60, bottom: 80, left: 100 };
    const chartWidth = canvas.width - margin.left - margin.right;
    const chartHeight = canvas.height - margin.top - margin.bottom;

    // Group results by execution type
    const threadResults = results.filter(r => r.executionType === "threads");
    const processResults = results.filter(r => r.executionType === "processes");

    // Metrics to display
    const metrics = Object.keys(showMetrics).filter(key => showMetrics[key as keyof typeof showMetrics]);
    const metricLabels: Record<string, string> = {
      executionTime: "Execution Time (ms)",
      cpuUsage: "CPU Usage (%)",
      memoryUsage: "Memory (MB)",
      overhead: "Overhead (ms)"
    };

    if (metrics.length === 0) return;

    // Draw chart background
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = "#f8f9fa";
    ctx.fillRect(margin.left, margin.top, chartWidth, chartHeight);

    // Draw grid lines
    ctx.strokeStyle = "#e9ecef";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 10; i++) {
      const y = margin.top + (chartHeight / 10) * i;
      ctx.beginPath();
      ctx.moveTo(margin.left, y);
      ctx.lineTo(margin.left + chartWidth, y);
      ctx.stroke();
    }

    if (chartType === "bar") {
      // Bar chart
      const barWidth = chartWidth / (metrics.length * 3);
      
      metrics.forEach((metric, metricIndex) => {
        const allValues = [...threadResults, ...processResults].map(r => r[metric as keyof TestResult] as number);
        const maxValue = Math.max(...allValues) || 1;
        const x = margin.left + metricIndex * (chartWidth / metrics.length);
        
        // Thread bar (blue)
        if (threadResults.length > 0) {
          const threadValue = threadResults[threadResults.length - 1][metric as keyof TestResult] as number;
          const threadHeight = (threadValue / maxValue) * chartHeight;
          
          // Gradient for threads
          const gradient = ctx.createLinearGradient(0, margin.top, 0, margin.top + chartHeight);
          gradient.addColorStop(0, "#60a5fa");
          gradient.addColorStop(1, "#3b82f6");
          ctx.fillStyle = gradient;
          
          ctx.fillRect(x + barWidth * 0.2, margin.top + chartHeight - threadHeight, barWidth * 0.8, threadHeight);
          
          // Value label
          ctx.fillStyle = "#1f2937";
          ctx.font = "12px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(
            threadValue.toFixed(1), 
            x + barWidth * 0.6, 
            margin.top + chartHeight - threadHeight - 5
          );
        }
        
        // Process bar (green)
        if (processResults.length > 0) {
          const processValue = processResults[processResults.length - 1][metric as keyof TestResult] as number;
          const processHeight = (processValue / maxValue) * chartHeight;
          
          // Gradient for processes
          const gradient = ctx.createLinearGradient(0, margin.top, 0, margin.top + chartHeight);
          gradient.addColorStop(0, "#34d399");
          gradient.addColorStop(1, "#10b981");
          ctx.fillStyle = gradient;
          
          ctx.fillRect(x + barWidth * 1.2, margin.top + chartHeight - processHeight, barWidth * 0.8, processHeight);
          
          // Value label
          ctx.fillStyle = "#1f2937";
          ctx.font = "12px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(
            processValue.toFixed(1), 
            x + barWidth * 1.6, 
            margin.top + chartHeight - processHeight - 5
          );
        }
      });
    } else {
      // Line chart
      const drawLineChart = (data: TestResult[], color: string, label: string) => {
        if (data.length < 2) return;

        metrics.forEach((metric, metricIndex) => {
          const allValues = data.map(r => r[metric as keyof TestResult] as number);
          const maxValue = Math.max(...allValues) || 1;
          const minValue = Math.min(...allValues) || 0;
          const range = maxValue - minValue || 1;

          ctx.strokeStyle = color;
          ctx.lineWidth = 2;
          ctx.beginPath();

          data.forEach((point, index) => {
            const x = margin.left + (index / (data.length - 1)) * chartWidth;
            const normalizedValue = (point[metric as keyof TestResult] as number - minValue) / range;
            const y = margin.top + chartHeight - (normalizedValue * chartHeight);

            if (index === 0) {
              ctx.moveTo(x, y);
            } else {
              ctx.lineTo(x, y);
            }
          });

          ctx.stroke();

          // Draw points
          ctx.fillStyle = color;
          data.forEach((point, index) => {
            const x = margin.left + (index / (data.length - 1)) * chartWidth;
            const normalizedValue = (point[metric as keyof TestResult] as number - minValue) / range;
            const y = margin.top + chartHeight - (normalizedValue * chartHeight);
            
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, 2 * Math.PI);
            ctx.fill();
          });
        });
      };

      if (threadResults.length > 0) drawLineChart(threadResults, "#3b82f6", "Threads");
      if (processResults.length > 0) drawLineChart(processResults, "#10b981", "Processes");
    }

    // Draw labels
    ctx.fillStyle = "#374151";
    ctx.font = "14px sans-serif";
    ctx.textAlign = "center";
    
    metrics.forEach((metric, index) => {
      const x = margin.left + index * (chartWidth / metrics.length) + (chartWidth / metrics.length) / 2;
      ctx.fillText(metricLabels[metric], x, canvas.height - 30);
    });

    // Draw legend
    ctx.fillStyle = "#3b82f6";
    ctx.fillRect(margin.left, 20, 20, 15);
    ctx.fillStyle = "#374151";
    ctx.font = "16px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("Threads", margin.left + 30, 32);

    ctx.fillStyle = "#10b981";
    ctx.fillRect(margin.left + 120, 20, 20, 15);
    ctx.fillText("Processes", margin.left + 150, 32);

    // Draw title
    ctx.fillStyle = "#1f2937";
    ctx.font = "20px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Detailed Performance Analysis", canvas.width / 2, 25);

  }, [results, chartType, showMetrics]);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold">Performance Visualization</h3>
        
        <div className="flex items-center space-x-4">
          {/* Chart Type Toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setChartType("bar")}
              className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                chartType === "bar" 
                  ? "bg-white text-blue-600 shadow-sm" 
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Bar Chart
            </button>
            <button
              onClick={() => setChartType("line")}
              className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                chartType === "line" 
                  ? "bg-white text-blue-600 shadow-sm" 
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Line Chart
            </button>
          </div>
        </div>
      </div>

      {/* Metric Toggles */}
      <div className="flex flex-wrap gap-2 mb-6">
        {Object.entries(showMetrics).map(([metric, enabled]) => (
          <button
            key={metric}
            onClick={() => setShowMetrics(prev => ({ ...prev, [metric]: !enabled }))}
            className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
              enabled
                ? "bg-blue-100 text-blue-800 border border-blue-200"
                : "bg-gray-100 text-gray-600 border border-gray-200 hover:bg-gray-200"
            }`}
          >
            {metric.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
          </button>
        ))}
      </div>

      <div className="flex justify-center">
        <canvas
          ref={canvasRef}
          className="border border-gray-200 rounded-lg shadow-sm"
          style={{ maxWidth: "100%", height: "auto" }}
        />
      </div>
    </div>
  );
}
