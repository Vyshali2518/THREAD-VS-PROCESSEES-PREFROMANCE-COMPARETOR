import { useState } from "react";

interface TestHistoryProps {
  history: Array<{
    _id: string;
    taskType: string;
    taskSize: number;
    executionType: string;
    executionTime: number;
    cpuUsage: number;
    memoryUsage: number;
    overhead: number;
    result: number;
    timestamp: number;
  }>;
}

export function TestHistory({ history }: TestHistoryProps) {
  const [sortBy, setSortBy] = useState<"timestamp" | "executionTime" | "cpuUsage" | "memoryUsage">("timestamp");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [filterType, setFilterType] = useState<"all" | "threads" | "processes">("all");
  const [filterTask, setFilterTask] = useState<"all" | "prime" | "fibonacci" | "matrix">("all");

  const filteredAndSortedHistory = history
    .filter(test => filterType === "all" || test.executionType === filterType)
    .filter(test => filterTask === "all" || test.taskType === filterTask)
    .sort((a, b) => {
      const aVal = a[sortBy];
      const bVal = b[sortBy];
      const multiplier = sortOrder === "asc" ? 1 : -1;
      return (aVal > bVal ? 1 : -1) * multiplier;
    });

  const handleSort = (column: typeof sortBy) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("desc");
    }
  };

  const getSortIcon = (column: string) => {
    if (sortBy !== column) return "↕️";
    return sortOrder === "asc" ? "↑" : "↓";
  };

  const getPerformanceRating = (test: any) => {
    // Simple performance rating based on execution time and resource usage
    const timeScore = Math.max(0, 100 - (test.executionTime / 50));
    const cpuScore = Math.max(0, 100 - test.cpuUsage);
    const memoryScore = Math.max(0, 100 - (test.memoryUsage * 2));
    const overallScore = (timeScore + cpuScore + memoryScore) / 3;
    
    if (overallScore >= 80) return { rating: "Excellent", color: "text-green-600", bg: "bg-green-100" };
    if (overallScore >= 60) return { rating: "Good", color: "text-blue-600", bg: "bg-blue-100" };
    if (overallScore >= 40) return { rating: "Fair", color: "text-yellow-600", bg: "bg-yellow-100" };
    return { rating: "Poor", color: "text-red-600", bg: "bg-red-100" };
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold">Test History</h2>
        <div className="text-sm text-gray-500">
          {filteredAndSortedHistory.length} of {history.length} tests
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Execution Type
          </label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="px-3 py-1 border border-gray-300 rounded text-sm"
          >
            <option value="all">All Types</option>
            <option value="threads">Threads Only</option>
            <option value="processes">Processes Only</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Task Type
          </label>
          <select
            value={filterTask}
            onChange={(e) => setFilterTask(e.target.value as any)}
            className="px-3 py-1 border border-gray-300 rounded text-sm"
          >
            <option value="all">All Tasks</option>
            <option value="prime">Prime Numbers</option>
            <option value="fibonacci">Fibonacci</option>
            <option value="matrix">Matrix Multiplication</option>
          </select>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b bg-gray-50">
              <th 
                className="text-left py-3 px-4 font-semibold cursor-pointer hover:bg-gray-100 transition-colors"
                onClick={() => handleSort("timestamp")}
              >
                Date {getSortIcon("timestamp")}
              </th>
              <th className="text-left py-3 px-4 font-semibold">Task</th>
              <th className="text-left py-3 px-4 font-semibold">Size</th>
              <th className="text-left py-3 px-4 font-semibold">Type</th>
              <th 
                className="text-left py-3 px-4 font-semibold cursor-pointer hover:bg-gray-100 transition-colors"
                onClick={() => handleSort("executionTime")}
              >
                Time (ms) {getSortIcon("executionTime")}
              </th>
              <th 
                className="text-left py-3 px-4 font-semibold cursor-pointer hover:bg-gray-100 transition-colors"
                onClick={() => handleSort("cpuUsage")}
              >
                CPU (%) {getSortIcon("cpuUsage")}
              </th>
              <th 
                className="text-left py-3 px-4 font-semibold cursor-pointer hover:bg-gray-100 transition-colors"
                onClick={() => handleSort("memoryUsage")}
              >
                Memory (MB) {getSortIcon("memoryUsage")}
              </th>
              <th className="text-left py-3 px-4 font-semibold">Overhead (ms)</th>
              <th className="text-left py-3 px-4 font-semibold">Result</th>
              <th className="text-left py-3 px-4 font-semibold">Rating</th>
            </tr>
          </thead>
          <tbody>
            {filteredAndSortedHistory.map((test) => {
              const rating = getPerformanceRating(test);
              return (
                <tr key={test._id} className="border-b hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4 text-sm">
                    <div>{new Date(test.timestamp).toLocaleDateString()}</div>
                    <div className="text-xs text-gray-500">
                      {new Date(test.timestamp).toLocaleTimeString()}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="capitalize font-medium">{test.taskType}</span>
                  </td>
                  <td className="py-3 px-4 font-mono text-sm">
                    {test.taskSize.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      test.executionType === "threads" 
                        ? "bg-blue-100 text-blue-800" 
                        : "bg-green-100 text-green-800"
                    }`}>
                      {test.executionType}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono">{test.executionTime}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center">
                      <div className="w-12 bg-gray-200 rounded-full h-1.5 mr-2">
                        <div 
                          className="bg-orange-500 h-1.5 rounded-full"
                          style={{ width: `${Math.min(test.cpuUsage, 100)}%` }}
                        />
                      </div>
                      <span className="text-sm font-mono">{test.cpuUsage}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono">{test.memoryUsage}</td>
                  <td className="py-3 px-4 font-mono">{test.overhead}</td>
                  <td className="py-3 px-4 font-mono text-sm">
                    {test.result.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${rating.bg} ${rating.color}`}>
                      {rating.rating}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {filteredAndSortedHistory.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No tests match the current filters
        </div>
      )}
    </div>
  );
}
