import { useMemo } from "react";

interface TestResult {
  taskType: string;
  taskSize: number;
  executionType: string;
  executionTime: number;
  cpuUsage: number;
  memoryUsage: number;
  overhead: number;
  result: number;
}

interface ComparisonTableProps {
  results: TestResult[];
}

export function ComparisonTable({ results }: ComparisonTableProps) {
  const comparison = useMemo(() => {
    const threadResults = results.filter(r => r.executionType === "threads");
    const processResults = results.filter(r => r.executionType === "processes");

    if (threadResults.length === 0 || processResults.length === 0) {
      return null;
    }

    const getAverage = (arr: TestResult[], key: keyof TestResult) => {
      const values = arr.map(r => r[key] as number);
      return values.reduce((sum, val) => sum + val, 0) / values.length;
    };

    const threadAvg = {
      executionTime: getAverage(threadResults, "executionTime"),
      cpuUsage: getAverage(threadResults, "cpuUsage"),
      memoryUsage: getAverage(threadResults, "memoryUsage"),
      overhead: getAverage(threadResults, "overhead"),
    };

    const processAvg = {
      executionTime: getAverage(processResults, "executionTime"),
      cpuUsage: getAverage(processResults, "cpuUsage"),
      memoryUsage: getAverage(processResults, "memoryUsage"),
      overhead: getAverage(processResults, "overhead"),
    };

    return {
      threads: threadAvg,
      processes: processAvg,
      winner: {
        executionTime: threadAvg.executionTime < processAvg.executionTime ? "threads" : "processes",
        cpuUsage: threadAvg.cpuUsage < processAvg.cpuUsage ? "threads" : "processes",
        memoryUsage: threadAvg.memoryUsage < processAvg.memoryUsage ? "threads" : "processes",
        overhead: threadAvg.overhead < processAvg.overhead ? "threads" : "processes",
      }
    };
  }, [results]);

  if (!comparison) {
    return (
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-semibold mb-4">Performance Comparison</h3>
        <p className="text-gray-500 text-center py-8">
          Run tests with both threads and processes to see comparison
        </p>
      </div>
    );
  }

  const formatValue = (value: number, unit: string) => {
    return `${value.toFixed(2)}${unit}`;
  };

  const getWinnerBadge = (metric: keyof typeof comparison.winner) => {
    const winner = comparison.winner[metric];
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
        winner === "threads" 
          ? "bg-blue-100 text-blue-800" 
          : "bg-green-100 text-green-800"
      }`}>
        {winner} wins
      </span>
    );
  };

  const getPerformanceDiff = (threadsVal: number, processesVal: number, lowerIsBetter = true) => {
    const diff = lowerIsBetter 
      ? ((processesVal - threadsVal) / processesVal) * 100
      : ((threadsVal - processesVal) / threadsVal) * 100;
    
    const absValue = Math.abs(diff);
    const color = diff > 0 ? "text-green-600" : "text-red-600";
    const symbol = diff > 0 ? "↓" : "↑";
    
    return (
      <span className={`text-sm ${color} font-medium`}>
        {symbol} {absValue.toFixed(1)}%
      </span>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <h3 className="text-lg font-semibold mb-4">Performance Comparison</h3>
      
      <div className="space-y-4">
        {/* Execution Time */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex-1">
            <div className="font-medium text-gray-900">Execution Time</div>
            <div className="text-sm text-gray-600">Lower is better</div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-blue-600 font-mono">
                {formatValue(comparison.threads.executionTime, "ms")}
              </div>
              <div className="text-xs text-gray-500">threads</div>
            </div>
            <div className="text-right">
              <div className="text-green-600 font-mono">
                {formatValue(comparison.processes.executionTime, "ms")}
              </div>
              <div className="text-xs text-gray-500">processes</div>
            </div>
            <div className="flex flex-col items-end space-y-1">
              {getWinnerBadge("executionTime")}
              {getPerformanceDiff(comparison.threads.executionTime, comparison.processes.executionTime)}
            </div>
          </div>
        </div>

        {/* CPU Usage */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex-1">
            <div className="font-medium text-gray-900">CPU Usage</div>
            <div className="text-sm text-gray-600">Lower is better</div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-blue-600 font-mono">
                {formatValue(comparison.threads.cpuUsage, "%")}
              </div>
              <div className="text-xs text-gray-500">threads</div>
            </div>
            <div className="text-right">
              <div className="text-green-600 font-mono">
                {formatValue(comparison.processes.cpuUsage, "%")}
              </div>
              <div className="text-xs text-gray-500">processes</div>
            </div>
            <div className="flex flex-col items-end space-y-1">
              {getWinnerBadge("cpuUsage")}
              {getPerformanceDiff(comparison.threads.cpuUsage, comparison.processes.cpuUsage)}
            </div>
          </div>
        </div>

        {/* Memory Usage */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex-1">
            <div className="font-medium text-gray-900">Memory Usage</div>
            <div className="text-sm text-gray-600">Lower is better</div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-blue-600 font-mono">
                {formatValue(comparison.threads.memoryUsage, "MB")}
              </div>
              <div className="text-xs text-gray-500">threads</div>
            </div>
            <div className="text-right">
              <div className="text-green-600 font-mono">
                {formatValue(comparison.processes.memoryUsage, "MB")}
              </div>
              <div className="text-xs text-gray-500">processes</div>
            </div>
            <div className="flex flex-col items-end space-y-1">
              {getWinnerBadge("memoryUsage")}
              {getPerformanceDiff(comparison.threads.memoryUsage, comparison.processes.memoryUsage)}
            </div>
          </div>
        </div>

        {/* Overhead */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex-1">
            <div className="font-medium text-gray-900">Overhead</div>
            <div className="text-sm text-gray-600">Lower is better</div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-blue-600 font-mono">
                {formatValue(comparison.threads.overhead, "ms")}
              </div>
              <div className="text-xs text-gray-500">threads</div>
            </div>
            <div className="text-right">
              <div className="text-green-600 font-mono">
                {formatValue(comparison.processes.overhead, "ms")}
              </div>
              <div className="text-xs text-gray-500">processes</div>
            </div>
            <div className="flex flex-col items-end space-y-1">
              {getWinnerBadge("overhead")}
              {getPerformanceDiff(comparison.threads.overhead, comparison.processes.overhead)}
            </div>
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-semibold text-blue-900 mb-2">Performance Summary</h4>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium">Threads win:</span>
            <span className="ml-2">
              {Object.values(comparison.winner).filter(w => w === "threads").length} metrics
            </span>
          </div>
          <div>
            <span className="font-medium">Processes win:</span>
            <span className="ml-2">
              {Object.values(comparison.winner).filter(w => w === "processes").length} metrics
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
