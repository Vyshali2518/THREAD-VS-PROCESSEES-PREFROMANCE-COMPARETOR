import { useState, useEffect } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { PerformanceChart } from "./PerformanceChart";
import { TestHistory } from "./TestHistory";
import { RealTimeChart } from "./RealTimeChart";
import { ComparisonTable } from "./ComparisonTable";

interface TestResult {
  taskType: string;
  taskSize: number;
  executionType: string;
  executionTime: number;
  cpuUsage: number;
  memoryUsage: number;
  overhead: number;
  result: number;
}

export function PerformanceComparator() {
  const [taskType, setTaskType] = useState("prime");
  const [taskSize, setTaskSize] = useState(1000);
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<TestResult[]>([]);
  const [currentTest, setCurrentTest] = useState<{
    type: string;
    progress: number;
    startTime: number;
  } | null>(null);
  const [autoRun, setAutoRun] = useState(false);
  const [testInterval, setTestInterval] = useState(5000);
  
  const runTest = useAction(api.performance.runPerformanceTest);
  const testHistory = useQuery(api.performance.getTestHistory);

  // Auto-run functionality
  useEffect(() => {
    if (!autoRun) return;
    
    const interval = setInterval(async () => {
      if (!isRunning) {
        const executionType = Math.random() > 0.5 ? "threads" : "processes";
        await handleRunTest(executionType as "threads" | "processes");
      }
    }, testInterval);

    return () => clearInterval(interval);
  }, [autoRun, testInterval, isRunning]);

  const handleRunTest = async (executionType: "threads" | "processes") => {
    if (isRunning) return;
    
    setIsRunning(true);
    setCurrentTest({
      type: executionType,
      progress: 0,
      startTime: Date.now()
    });

    // Simulate progress updates
    const progressInterval = setInterval(() => {
      setCurrentTest(prev => prev ? {
        ...prev,
        progress: Math.min(prev.progress + Math.random() * 20, 95)
      } : null);
    }, 200);

    try {
      const result = await runTest({
        taskType,
        taskSize,
        executionType,
      });
      
      setResults(prev => [...prev, result]);
      toast.success(`${executionType} test completed in ${result.executionTime}ms`);
    } catch (error) {
      toast.error("Test failed: " + (error as Error).message);
    } finally {
      clearInterval(progressInterval);
      setCurrentTest(null);
      setIsRunning(false);
    }
  };

  const clearResults = () => {
    setResults([]);
  };

  const runBothTests = async () => {
    await handleRunTest("threads");
    setTimeout(() => handleRunTest("processes"), 1000);
  };

  const getTaskDescription = (type: string) => {
    switch (type) {
      case "prime": return "Calculates prime numbers up to the specified limit";
      case "fibonacci": return "Computes Fibonacci sequence up to the nth term";
      case "matrix": return "Performs matrix multiplication on NxN matrices";
      default: return "";
    }
  };

  return (
    <div className="space-y-8">
      {/* Test Configuration */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h2 className="text-2xl font-semibold mb-6">Test Configuration</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Task Type
            </label>
            <select
              value={taskType}
              onChange={(e) => setTaskType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={isRunning}
            >
              <option value="prime">Prime Number Calculation</option>
              <option value="fibonacci">Fibonacci Sequence</option>
              <option value="matrix">Matrix Multiplication</option>
            </select>
            <p className="text-sm text-gray-500 mt-1">
              {getTaskDescription(taskType)}
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Task Size
            </label>
            <input
              type="range"
              value={taskSize}
              onChange={(e) => setTaskSize(Number(e.target.value))}
              min="100"
              max="10000"
              step="100"
              className="w-full mb-2"
              disabled={isRunning}
            />
            <div className="flex justify-between text-sm text-gray-500">
              <span>100</span>
              <span className="font-medium">{taskSize.toLocaleString()}</span>
              <span>10,000</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Auto-Run Settings
            </label>
            <div className="space-y-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={autoRun}
                  onChange={(e) => setAutoRun(e.target.checked)}
                  className="mr-2"
                  disabled={isRunning}
                />
                <span className="text-sm">Enable auto-run</span>
              </label>
              {autoRun && (
                <div>
                  <label className="block text-xs text-gray-600 mb-1">
                    Interval (ms)
                  </label>
                  <input
                    type="number"
                    value={testInterval}
                    onChange={(e) => setTestInterval(Number(e.target.value))}
                    min="1000"
                    max="30000"
                    step="1000"
                    className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
                    disabled={isRunning}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Progress Bar */}
        {currentTest && (
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-blue-800">
                Running {currentTest.type} test...
              </span>
              <span className="text-sm text-blue-600">
                {Math.round(currentTest.progress)}%
              </span>
            </div>
            <div className="w-full bg-blue-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${currentTest.progress}%` }}
              />
            </div>
          </div>
        )}
        
        <div className="flex flex-wrap gap-4 mt-6">
          <button
            onClick={() => handleRunTest("threads")}
            disabled={isRunning}
            className="flex-1 min-w-[140px] bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isRunning && currentTest?.type === "threads" ? "Running..." : "Run with Threads"}
          </button>
          
          <button
            onClick={() => handleRunTest("processes")}
            disabled={isRunning}
            className="flex-1 min-w-[140px] bg-green-600 text-white px-6 py-3 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isRunning && currentTest?.type === "processes" ? "Running..." : "Run with Processes"}
          </button>

          <button
            onClick={runBothTests}
            disabled={isRunning}
            className="flex-1 min-w-[140px] bg-purple-600 text-white px-6 py-3 rounded-md hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Run Both Tests
          </button>
          
          {results.length > 0 && (
            <button
              onClick={clearResults}
              disabled={isRunning}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Clear Results
            </button>
          )}
        </div>
      </div>

      {/* Real-time Performance Metrics */}
      {results.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <RealTimeChart results={results} />
          <ComparisonTable results={results} />
        </div>
      )}

      {/* Detailed Performance Chart */}
      {results.length >= 2 && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <PerformanceChart results={results} />
        </div>
      )}

      {/* Current Results Table */}
      {results.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-2xl font-semibold mb-6">Current Test Results</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left py-3 px-4 font-semibold">Execution Type</th>
                  <th className="text-left py-3 px-4 font-semibold">Time (ms)</th>
                  <th className="text-left py-3 px-4 font-semibold">CPU Usage (%)</th>
                  <th className="text-left py-3 px-4 font-semibold">Memory (MB)</th>
                  <th className="text-left py-3 px-4 font-semibold">Overhead (ms)</th>
                  <th className="text-left py-3 px-4 font-semibold">Result</th>
                  <th className="text-left py-3 px-4 font-semibold">Efficiency</th>
                </tr>
              </thead>
              <tbody>
                {results.map((result, index) => {
                  const efficiency = Math.round((result.result / result.executionTime) * 100) / 100;
                  return (
                    <tr key={index} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-3 px-4">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          result.executionType === "threads" 
                            ? "bg-blue-100 text-blue-800" 
                            : "bg-green-100 text-green-800"
                        }`}>
                          {result.executionType}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono">{result.executionTime}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-orange-500 h-2 rounded-full"
                              style={{ width: `${Math.min(result.cpuUsage, 100)}%` }}
                            />
                          </div>
                          <span className="text-sm">{result.cpuUsage}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">{result.memoryUsage}</td>
                      <td className="py-3 px-4">{result.overhead}</td>
                      <td className="py-3 px-4 font-mono">{result.result.toLocaleString()}</td>
                      <td className="py-3 px-4 font-mono text-sm">{efficiency}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Test History */}
      {testHistory && testHistory.length > 0 && (
        <TestHistory history={testHistory} />
      )}
    </div>
  );
}
